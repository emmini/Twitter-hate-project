﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NewsEventDetection.Repositories;

namespace NewsEventDetection.Controllers
{
    [Route("/")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly ITweetRepository _tweetRepository;
        public ValuesController(ITweetRepository tweetRepository)
        {
            _tweetRepository = tweetRepository;
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<string>>> Get()
        {
            //var ab = TwitterNewsDataRequestService.RequestData("https://api.twitter.com/1.1/search/tweets.json", "azBZrSXP7P37QS3r7CyqqTt9N", "FNKftCwhMPupeSS6Kue0LRA45bur3Riwa7NyjDtS8vEQB84U0d", "883344889076998147-Vz1xGBknUqXyNpcCsb0DB9SOEWReqgC", "HTlY6kL8l79eRWRr6sQGtGBcuTrWGwzOdqlHgEeDphvBz");
            var tweets = _tweetRepository.Query();
            var news = await _tweetRepository.GetNewsTweets();
            _tweetRepository.FilterTweets(tweets);
            _tweetRepository.FilterTweets(news);
            await _tweetRepository.GetTopics(tweets);
            _tweetRepository.GetTweetJaccard(news, tweets);
            _tweetRepository.GetDegreeOfSupport(tweets);
            await _tweetRepository.GetTopicSpottingMeasures(tweets);
            return new JsonResult(tweets);
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}