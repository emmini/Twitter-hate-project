﻿using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace NewsEventDetection.Extractor.NGram
{
    abstract class NgramsExtractor: INgramsExtractor
    {

        public NgramsExtractor()
        {
            Ngrams = new Dictionary<string, int>();
            StopWords = new HashSet<string>();
        }
            
        public IDictionary<string, int> Ngrams { get; set; }
        protected IList<string> AllTerms { get; set; }

        public ISet<string> StopWords { get; set; }
        


        private string source;
        public string Source
        {
            get => source;
            set => source = value.Trim();
        }




        /**
         * Extracts the Ngrams from the input.
         */
        public void Extract(int n)
        {
            Source = Source.ToLower();
            AssignTerms();
            GenerateNgrams(AllTerms, n);
        }



        protected abstract void AssignTerms();


        protected IList<string> DeconstructInput () =>
            Regex.Split(Source, "\\s+");



        protected IList<string> RemoveStopWords(IList<string> source)
        {
            var sw = StopWords.Select(t => t.ToLower());
            return source.Where(term => !sw.Contains(term.ToLower())).ToList();
        }



        protected string ReconstructInput(IList<string> source)
        {
            var input = "";
            
            foreach(var term in source)
            {
                input += (term + " ");
            }

            input.Trim();
            return input;
        }



        protected void GenerateNgrams(IList<string> source, int n)
        {
            var count = source.Count;
            for (var i = 0; i < count - 3; i++)
            {
                var Ngram = "";
                var start = i;
                var end = i + n;
                for (var j = start; j < end; j++)
                {
                    Ngram += ((source[j].Length == 1) ? source[j] : (source[j] + " "));
                }

                Ngram.Replace("#", string.Empty);
                if (!Ngrams.ContainsKey(Ngram))
                {
                    Ngrams.Add(Ngram, 1);
                }
                else
                {
                    Ngrams[Ngram]++;
                }
            }
        }
    }
}
