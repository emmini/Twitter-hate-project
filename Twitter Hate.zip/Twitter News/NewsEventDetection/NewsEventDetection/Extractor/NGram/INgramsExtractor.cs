﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsEventDetection.Extractor.NGram
{
    interface INgramsExtractor
    {
        string Source { get; set; }
        IDictionary<string, int> Ngrams { get; }

        ISet<string> StopWords { get; set; }

        void Extract(int n);
    }
}
