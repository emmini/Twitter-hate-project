﻿using System.Linq;

namespace NewsEventDetection.Extractor.NGram
{
    class CharNgramsExtractor : NgramsExtractor
    {
        protected override void AssignTerms () =>
            AllTerms = ReconstructInput(RemoveStopWords(DeconstructInput())).Select(c => c.ToString()).ToList();
    }
}
