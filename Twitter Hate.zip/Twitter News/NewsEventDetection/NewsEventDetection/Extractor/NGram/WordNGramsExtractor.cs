﻿namespace NewsEventDetection.Extractor.NGram
{
    class WordNgramsExtractor : NgramsExtractor
    {
        protected override void AssignTerms () =>
            AllTerms = RemoveStopWords(DeconstructInput());
    }
}