﻿using Microsoft.EntityFrameworkCore;
using NewsEventDetection.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsEventDetection.Repositories
{
    public abstract class GenericRepository<T> : IGenericRepository<T>
        where T: BaseEntity, new()
    {
        protected Context<T> _dbContext { get; set; }

        public async Task<T> GetAsync(string id)
        {
            return await _dbContext.FindAsync(id);
        }

        public IQueryable<T> Query()
        {
            return _dbContext.TweetData.AsQueryable();
        }

        public async Task InsertAsync(T entity)
        {
            entity.CreatedAt = DateTimeOffset.UtcNow;
            entity.UpdatedAt = DateTimeOffset.UtcNow;

            _dbContext.TweetData.Add(entity);
            await SaveChangesAsync();
        }

        public async Task UpdateAsync(T entity)
        {
            entity.UpdatedAt = DateTimeOffset.UtcNow;

            _dbContext.TweetData.Update(entity);
            await SaveChangesAsync();
        }

        public async Task DeleteAsync(string id)
        {
            T entity = new T() { Id = id };

            _dbContext.TweetData.Remove(entity);
            await SaveChangesAsync();
        }

        public Task SaveChangesAsync()
        {
            return _dbContext.SaveChangesAsync();
        }
    }
}
