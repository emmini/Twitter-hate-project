﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NewsEventDetection.Domain;
using Clusters = System.Collections.Generic.IDictionary<string, System.Collections.Generic.ICollection<(NewsEventDetection.Domain.Tweet tweet, double score)>>;

namespace NewsEventDetection.Repositories
{
    public interface ITweetRepository: IGenericRepository<Tweet>
    {
        Tweet FilterTweet(Tweet tweet);

        IEnumerable<Tweet> FilterTweets(IEnumerable<Tweet> tweets);

        IEnumerable<string> GetTopics(Tweet tweet);

        Task<IQueryable<Topic>> GetTopics();

        Task<IEnumerable<IEnumerable<string>>> GetTopics(IEnumerable<Tweet> tweets);

        double GetTweetJaccard(IEnumerable<Tweet> newstweets, Tweet tweet);

        IEnumerable<double> GetTweetJaccard(IEnumerable<Tweet> newstweets, IEnumerable<Tweet> tweets);

        double GetDegreeOfSupport(Tweet tweet);

        IEnumerable<double> GetDegreeOfSupport(IEnumerable<Tweet> tweets);

        double GetDegreeOfSupport(IEnumerable<Tweet> newstweets, Tweet tweet);

        IEnumerable<Tweet> GetSeeders(IEnumerable<Tweet> tweets, double threshold);

        Task<IQueryable<Tweet>> GetNewsTweets();

        Task<(string, double)> GetTopicSpottingMeasure(IEnumerable<Tweet> tweets, Tweet tweet, Topic topic);

        Task<IDictionary<string, double>> GetTopicSpottingMeasure(IEnumerable<Tweet> tweets, Tweet tweet);

        Task<Clusters> GetTopicSpottingMeasures (IEnumerable<Tweet> tweets);

        double GetMean (Clusters clusters);
        double GetSD (Clusters clusters);
    }
}
