﻿using Microsoft.Extensions.Configuration;
using NewsEventDetection.Domain;
using NewsEventDetection.Extractor.NGram;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NewsEventDetection.Repositories
{
    public class TweetRepository : GenericRepository<Tweet>, ITweetRepository
    {
        public readonly string _newspath;
        public readonly string _topicpath;

        public TweetRepository(IConfiguration configuration)
        {
            var path = configuration.GetSection("paths:tweetdata").Value;
            _newspath = configuration.GetSection("paths:newsdata").Value;
            _topicpath = configuration.GetSection("paths:topicdata").Value;
            _dbContext = new Context<Tweet>(path)
            {
                Path = path
            };

        }

        public Tweet FilterTweet(Tweet tweet)
        {
            if (string.IsNullOrEmpty(tweet.Text))
            {
                tweet.Text = string.Empty;
                tweet.FilteredText = string.Empty;
                return tweet;
            }
            var pattern = @"[^a-zA-Z0-9@#\s-]*";
            var regex = new Regex(pattern, RegexOptions.Compiled);
            tweet.FilteredText = regex.Replace(tweet.Text, string.Empty);
            return tweet;
        }

        public IEnumerable<Tweet> FilterTweets(IEnumerable<Tweet> tweets)
        {
            var list = new List<Tweet>();
            foreach (var tweet in tweets)
            {
                list.Add(FilterTweet(tweet));
                //yield return FilterTweet(tweet);
            }
            return list;
        }

        public IEnumerable<string> GetTopics(Tweet tweet)
        {
            if (string.IsNullOrEmpty(tweet.Text))
            {
                return tweet.Topics.Union(new List<string>());
            }

            var pattern = @"#\w+\b";
            var regex = new Regex(pattern, RegexOptions.Compiled);
            tweet.Topics = regex.Matches(tweet.Text).Select(m => m.Value.Replace("#", string.Empty)).Union(tweet.Topics).Distinct();
            return tweet.Topics;
        }

        public async Task<IEnumerable<IEnumerable<string>>> GetTopics(IEnumerable<Tweet> tweets)
        {
            var list = new List<IEnumerable<string>>();
            foreach (var tweet in tweets)
            {
                var topics = GetTopics(tweet);
                list.Add(topics);
                //yield return GetTopics(tweet);
            }
            await _dbContext.Topics.AddRangeAsync(list.SelectMany(t => t).Distinct().Select(t => new Topic {Id = t, Value = t, CreatedAt = DateTimeOffset.Now }));
            await _dbContext.SaveTopicsChangesAsync(_topicpath);
            return list;
        }

        public double GetTweetJaccard(IEnumerable<Tweet> newstweets, Tweet tweet)
        {
            foreach(var t in newstweets)
            {
                var jaccard = (double)t.NGrams.Intersect(tweet.NGrams).Count() / t.NGrams.Union(tweet.NGrams).Count();
                tweet.TweetJacards[t.Id] = jaccard;
            }
            return tweet.TweetJacards.Values.Max();
        }

        public IEnumerable<double> GetTweetJaccard(IEnumerable<Tweet> newstweets, IEnumerable<Tweet> tweets)
        {
            var list = new List<double>();

            foreach (var tweet in tweets)
            {
                list.Add(GetTweetJaccard(newstweets, tweet));
                //yield return GetJaccard(newstweets,tweet);
            }
            return list;
        }

        public double GetDegreeOfSupport(Tweet tweet)
        {
            var x = tweet.FilteredText.Split().Count();
            tweet.DegreeOfSupport = tweet.TweetJaccard / x;
            return tweet.DegreeOfSupport;
        }

        public IEnumerable<double> GetDegreeOfSupport(IEnumerable<Tweet> tweets)
        {
            var list = new List<double>();

            foreach (var tweet in tweets)
            {
                list.Add(GetDegreeOfSupport(tweet));
                //yield return GetDegreeOfSupport(tweet);
            }
            return list;
        }

        public double GetDegreeOfSupport(IEnumerable<Tweet> newstweets, Tweet tweet)
        {
            GetTweetJaccard(newstweets, tweet);
            return GetDegreeOfSupport(tweet);
        }

        public IEnumerable<Tweet> GetSeeders(IEnumerable<Tweet> tweets, double threshold)
        {
            return tweets.Where(t => t.DegreeOfSupport >= threshold);
        }

        public async Task<IQueryable<Tweet>> GetNewsTweets()
        {
            return await _dbContext.LoadNews(_newspath);
        }

        public async Task<IQueryable<Topic>> GetTopics()
        {
            return  await _dbContext.LoadTopics(_topicpath);
        }

        public async Task<(string,double)> GetTopicSpottingMeasure(IEnumerable<Tweet> tweets, Tweet tweet, Topic topic)
        {
            var topics = tweets.SelectMany(t => t.Topics);
            var topicscount = topics.Count();
            var topicfrequency = topics.Where(t => t.Equals(topic.Value, StringComparison.OrdinalIgnoreCase)).Count();
            var topicprobability = (double)topicfrequency / topicscount;
            var tweetscount = tweets.Count();
            var tweetsfrequency = tweets.Where(t => t.FilteredText.Equals(tweet.FilteredText, StringComparison.OrdinalIgnoreCase)).Count();
            var tweetprobability = (double)tweetsfrequency / tweetscount;
            
                    
            var bayes = tweet.NGrams.Keys.Intersect(topic.NGrams.Keys).Count() / tweetprobability;

            var spottingMeasure =  (value: topic.Value, prob: Math.Log(bayes / topicprobability));
            tweet.SpottingMeasures.Add(spottingMeasure.value, spottingMeasure.prob);
            await SaveChangesAsync();
            await _dbContext.SaveTopicsChangesAsync(_topicpath);
            return spottingMeasure;
        }

        public async Task<IDictionary<string,double>> GetTopicSpottingMeasure(IEnumerable<Tweet> tweets, Tweet tweet)
        {
            var topics = await GetTopics();
            var topicSpottingMeasure = new Dictionary<string, double>();
            foreach (var topic in topics)
            {
                var spottingmeasure = await GetTopicSpottingMeasure(tweets, tweet, topic);
                topicSpottingMeasure.Add(spottingmeasure.Item1, spottingmeasure.Item2);
            }
            tweet.SpottingMeasures = topicSpottingMeasure;
            return topicSpottingMeasure;
        }

        public async Task<IDictionary<string, ICollection<(Tweet tweet, double score)>>> GetTopicSpottingMeasures(IEnumerable<Tweet> tweets)
        {
            var list = new Dictionary<string, ICollection<(Tweet tweet, double score)>>();
            foreach (var tweet in tweets)
            {
                var spottingMeasures =  await GetTopicSpottingMeasure(tweets, tweet);
                var maxTopic = string.Empty;
                var maxScore = double.MinValue;

                foreach(var (t, s) in spottingMeasures)
                {
                    if (s > maxScore || maxScore == int.MinValue)
                    {
                        maxTopic = t;
                        maxScore = s;
                    }
                }

                if (!list.TryGetValue(maxTopic, out var collection))
                {
                    collection = new List<(Tweet, double)>();
                    list[maxTopic] = collection;
                }

                collection.Add((tweet, maxScore));
            }
            return list;
        }
    }
}