﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsEventDetection.Providers.NewsDataProvider.Twitter
{
    public class TwitterNewsDataResult : INewsDataResult<TweetModel>
    {
        public TwitterNewsDataResult()
        {

        }
        public TwitterNewsDataResult(string json)
        {
            JObject data = JObject.Parse(json);
            NewsData = JsonConvert.DeserializeObject<IEnumerable<TweetModel>>(data["statuses"].ToString());
        }

        public IEnumerable<TweetModel> NewsData { get; set; }
    }
}
