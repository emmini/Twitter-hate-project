﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace NewsEventDetection.Providers.NewsDataProvider.Twitter
{
    public class TwitterDataProvider : BaseProvider<TweetModel>
    {
        public TwitterDataProvider(TwitterConfigInfo configInfo, DateTimeOffset from, string filter = "")
        {
            NewsDataRequestInfo = new TwitterDataRequestInfo
            {
                Filter = filter,
                From = from.DateTime
            };
            ConfigInfo = configInfo;
        }

        public TwitterConfigInfo ConfigInfo { get; set; }

        public string EncodeParameters(Dictionary<string, string> parameters)
        {
            if (parameters.Count == 0)
                return string.Empty;
            Dictionary<string, string>.KeyCollection.Enumerator keys = parameters.Keys.GetEnumerator();
            keys.MoveNext();
            StringBuilder sb = new StringBuilder($"{keys.Current}={ Uri.EscapeDataString(parameters[keys.Current])}");
            while (keys.MoveNext())
                sb.AppendFormat("&{0}={1}", keys.Current, Uri.EscapeDataString(parameters[keys.Current]));
            return sb.ToString();
        }

        public override INewsDataResult<TweetModel> RequestData()
        {
            try
            {
                HTTPClient client = new HTTPClient(5000, "Twitter search");
                client.oauth = new OAuth(ConfigInfo.ConsumerKey, ConfigInfo.ConsumerSecret, ConfigInfo.AccessToken, ConfigInfo.TokenSecret);
                Dictionary<string, string> parameters = new Dictionary<string, string>
                {
                    ["q"] = NewsDataRequestInfo.Filter
                };
                WebRequest request = client.CreateRequest("GET", ConfigInfo.RequestUrl, parameters);
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream stream = response.GetResponseStream())
                    {
                        using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                        {
                            var json = reader.ReadToEnd();

                            return new TwitterNewsDataResult(json);
                        }
                    }
                }

                //var parameters = new Dictionary<string, string>
                //{
                //    { "q", NewsDataRequestInfo.Filter },
                //    {"result_type", "popular" }
                // };
                //string url = $"{ConfigInfo.RequestUrl}?{EncodeParameters(parameters)}";
                ////string headers
                //HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                //request.Method = "GET";
                //request.ContentType = "application/x-www-form-urlencoded";
                ////request.Headers.Add("Authorization", "OAuth oauth_consumer_key=\"azBZrSXP7P37QS3r7CyqqTt9N\",oauth_token=\"883344889076998147-Vz1xGBknUqXyNpcCsb0DB9SOEWReqgC\",oauth_signature_method=\"HMAC-SHA1\",oauth_timestamp=\"1530896402\",oauth_nonce=\"kYjzVBB8Y0ZFabxSWbWovY3uYSQ2pTgmZeNu2VS4cg\",oauth_version=\"1.0\",oauth_signature=\"FDur043ASutDWNFgxSVodxoCjNQ%3D\"");
                //request.Headers.Add("Authorization", ConfigInfo.GetHeader(parameters));

                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;


                //// allows for validation of SSL conversations
                //ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };

                //var httpResponse = (HttpWebResponse)request.GetResponse();
                //using (var streamReader = new StreamReader(httpResponse.GetResponseStream(), Encoding.UTF8))
                //{
                //    var json = streamReader.ReadToEnd();

                //    return new TwitterNewsDataResult(json);
                //}
            }
            catch (WebException ex)
            {
                throw new Exception("The data provider is not available", ex);
            }
        }

    }

    public class TwitterDataRequestInfo : INewsDataRequestInfo
    {
        public DateTime From { get; set; }

        public string Filter { get; set; }
    }

    public class TweetModel
    {
        public string created_at { get; set; }

        public Int64 id { get; set; }

        public string text { get; set; }

        public bool truncated { get; set; }

        public CoordinateModel coordinates { get; set; }

        public IEnumerable<TopicModel> topics { get; set; }

    }

    public class CoordinateModel
    {
        double[] coordinates { get; set; }

        string type { get; set; }
    }

    public class TopicModel
    {
        int[] indices { get; set; }

        string text { get; set; }
    }
}
