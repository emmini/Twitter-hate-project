﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace NewsEventDetection.Providers.NewsDataProvider.Twitter
{
    public class TwitterConfigInfo
    {
        public TwitterConfigInfo(string url, string consumerKey, string consumerSecret,string accessToken, string tokenSecret)
        {
            RequestUrl = url;
            TokenSecret = tokenSecret;
            AccessToken = accessToken;
            ConsumerKey = consumerKey;
            ConsumerSecret = consumerSecret;
        }

        public string RequestUrl { get; set; }

        public string AccessToken { get; set; }

        public string TokenSecret { get; set; }

        public string ConsumerKey { get; set; }

        public string ConsumerSecret { get; set; }

        public static TimeSpan TimeSpan() => DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        public string OauthNonce => Convert.ToBase64String(new ASCIIEncoding().GetBytes(DateTime.Now.Ticks.ToString()));

        public string OauthSignatureMethod => "HMAC-SHA1";

        public string OauthTimeStamp => Convert.ToInt64(TimeSpan().TotalSeconds).ToString();

        public string OauthVersion => "1.0";

        public string RequestMethod => "GET";


        public string GetHeader(Dictionary<string, string> parameters)
        {
                           
            SortedDictionary<string, string> sd = new SortedDictionary<string, string>
            {
                { "oauth_version", OauthVersion },
                { "oauth_consumer_key", ConsumerKey },
                { "oauth_nonce", OauthNonce },
                { "oauth_signature_method", OauthSignatureMethod },
                { "oauth_timestamp", OauthTimeStamp },
                { "oauth_token", AccessToken }
            };

            if (parameters != null)
            {
                foreach (string key in parameters.Keys)
                    sd.Add(key, Uri.EscapeDataString(parameters[key]));
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}&{1}&", RequestMethod, Uri.EscapeDataString(RequestUrl));

            foreach (KeyValuePair<string, string> entry in sd)
            {
                sb.Append(Uri.EscapeDataString($"{entry.Key}={entry.Value}&"));
            }
            string baseString = sb.ToString().Substring(0, sb.Length - 3);

            string signingKey = $"{Uri.EscapeDataString(ConsumerSecret)}&{Uri.EscapeDataString(TokenSecret)}";
            HMACSHA1 hasher = new HMACSHA1(new ASCIIEncoding().GetBytes(signingKey));
            string oauth_signature = Convert.ToBase64String(hasher.ComputeHash(new ASCIIEncoding().GetBytes(baseString)));

            ServicePointManager.Expect100Continue = false;

            sb = new StringBuilder("OAuth ");
            sb.AppendFormat("oauth_consumer_key=\"{0}\",", Uri.EscapeDataString(ConsumerKey));
            sb.AppendFormat("oauth_nonce=\"{0}\",", Uri.EscapeDataString(OauthNonce));
            sb.AppendFormat("oauth_signature=\"{0}\",", Uri.EscapeDataString(oauth_signature));
            sb.AppendFormat("oauth_signature_method=\"{0}\",", Uri.EscapeDataString(OauthSignatureMethod));
            sb.AppendFormat("oauth_timestamp=\"{0}\",", Uri.EscapeDataString(OauthTimeStamp));
            sb.AppendFormat("oauth_token=\"{0}\",", Uri.EscapeDataString(AccessToken));
            sb.AppendFormat("oauth_version=\"{0}\"", Uri.EscapeDataString(OauthVersion));

            return sb.ToString();
        }
    }
}
