﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsEventDetection.Providers.NewsDataProvider
{
    public abstract class BaseProvider<T>: INewsDataProvider<T>
    {
        public INewsDataRequestInfo NewsDataRequestInfo { get; set; }

        public abstract INewsDataResult<T> RequestData();

    }
}
