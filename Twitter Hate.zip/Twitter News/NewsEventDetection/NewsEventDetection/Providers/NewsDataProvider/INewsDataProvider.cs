﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsEventDetection.Providers.NewsDataProvider
{
    interface INewsDataProvider<T>
    {
        INewsDataRequestInfo NewsDataRequestInfo { get; set; }

        INewsDataResult<T> RequestData();
    }

    public interface INewsDataRequestInfo
    {
        DateTime From { get; set; }

        string Filter { get; set; }    
    }
}
