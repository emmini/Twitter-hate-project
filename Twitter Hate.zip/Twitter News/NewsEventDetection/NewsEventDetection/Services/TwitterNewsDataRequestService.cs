﻿using NewsEventDetection.Providers.NewsDataProvider;
using NewsEventDetection.Providers.NewsDataProvider.Twitter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NewsEventDetection.Services
{
    public class TwitterNewsDataRequestService
    {
        public static INewsDataResult<TweetModel> RequestData(string url, string consumerKey, string consumerSecret, string accessToken, string tokenSecret)
        {
            var config = new TwitterConfigInfo(url, consumerKey, consumerSecret, accessToken, tokenSecret);
            var provider = new TwitterDataProvider(config, DateTime.Now, filter: "lagos");
            return provider.RequestData();
        }        
    }
}
