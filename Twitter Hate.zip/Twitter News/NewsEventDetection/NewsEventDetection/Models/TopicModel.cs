﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsEventDetection.Models
{
    public class TopicModel
    {
        int[] indices { get; set; }
        
        string text { get; set; }
    }
}
