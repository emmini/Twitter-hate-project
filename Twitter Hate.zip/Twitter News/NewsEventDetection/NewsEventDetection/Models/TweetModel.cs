﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsEventDetection.Models
{
    public class TweetModel
    {
        public string created_at { get; set; }

        public Int64 id { get; set; }

        public string text { get; set; }

        public bool truncated { get; set; }

        public CoordinateModel coordinates { get; set; }

        public IEnumerable<TopicModel> topics { get; set; }

    }
}
