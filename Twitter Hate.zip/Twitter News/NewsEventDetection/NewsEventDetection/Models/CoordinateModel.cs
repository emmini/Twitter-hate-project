﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsEventDetection.Models
{
    public class CoordinateModel
    {
        double[] coordinates { get; set; }

        string type { get; set; }
    }
}
