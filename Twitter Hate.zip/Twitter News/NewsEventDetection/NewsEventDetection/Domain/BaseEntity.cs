﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NewsEventDetection.Domain
{
    public abstract class BaseEntity : IEquatable<BaseEntity>
    {
        public string Id { get; set; }

        public DateTimeOffset CreatedAt { get; set; }

        public DateTimeOffset UpdatedAt { get; set; }

        //public int CompareTo(BaseEntity obj)
        //{
        //    if (Id == obj.Id)
        //        return 0;
        //    else if (Id > obj.Id)
        //        return 1;
        //    else
        //        return -1;
        //}

        public bool Equals(BaseEntity other)
        {
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }


        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

    }
}
