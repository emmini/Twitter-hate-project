﻿using JetBrains.Annotations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace NewsEventDetection.Domain
{
    public class DbSetHelper<TEntity> : DbSet<TEntity>, IQueryable<TEntity>, IAsyncEnumerable<TEntity> where TEntity:class
    {
        private readonly IEnumerable<PropertyInfo> keys;
        private readonly ICollection<TEntity> items;
        private readonly IQueryable<TEntity> query;

        public DbSetHelper()
        {
            keys = typeof(TEntity).GetProperties()
                                  .Where(p => Attribute.IsDefined(p, typeof(KeyAttribute))
                                           || "Id".Equals(p.Name, StringComparison.Ordinal))
                                           .ToList();
            items = new List<TEntity>();
            query = items.AsQueryable();
        }

        public DbSetHelper(IEnumerable<TEntity> entities)
        {
            if (entities == null)
                throw new ArgumentNullException(nameof(entities));

            keys = typeof(TEntity).GetProperties()
                                  .Where(p => Attribute.IsDefined(p, typeof(KeyAttribute))
                                           || "Id".Equals(p.Name, StringComparison.Ordinal))
                                           .ToList();
            items = entities.ToList();
            query = items.AsQueryable();
        }

        public new  TEntity Add(TEntity entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            if (keys.Any(k => k.GetValue(entity) == null))
                throw new ArgumentOutOfRangeException(nameof(entity));

            items.Add(entity);
            return entity;
        }

        public override void AddRange(IEnumerable<TEntity> entities)
        {
            if (entities == null)
                throw new ArgumentNullException(nameof(entities));

            entities.Select(Add).ToList();
        }

        public override Task AddRangeAsync(params TEntity[] entities)
        {
            AddRange(entities);
            return Task.FromResult(0);
        }

        public override Task AddRangeAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            AddRange(entities);
            return Task.FromResult(0);
        }


        public new TEntity Attach(TEntity entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            if (keys.Any(k => k.GetValue(entity) == null))
                throw new ArgumentOutOfRangeException(nameof(entity));

            var item = items.SingleOrDefault(i =>
                keys.All(k => k.GetValue(entity).Equals(k.GetValue(i)))
            );

            if (item == null)
                items.Add(entity);
            return item ?? entity;
        }


        public  TDerivedEntity Create<TDerivedEntity>()
        {
            return Activator.CreateInstance<TDerivedEntity>();
        }

        public TEntity Create()
        {
            return Activator.CreateInstance<TEntity>();
        }

        public int Count()
        {
            return items.Count;
        }

        public override TEntity Find(params object[] keyValues)
        {
            if (keyValues == null)
                throw new ArgumentNullException(nameof(keyValues));
            if (keyValues.Any(k => k == null))
                throw new ArgumentOutOfRangeException(nameof(keyValues));
            if (keyValues.Length != keys.Count())
                throw new ArgumentOutOfRangeException(nameof(keyValues));

            return items.SingleOrDefault(i =>
                keys.Zip(keyValues, (k, v) => v.Equals(k.GetValue(i)))
                    .All(r => r)
            );
        }

        public override Task<TEntity> FindAsync(params object[] keyValues)
        {
            return Task.FromResult(Find(keyValues));
        }

        public override Task<TEntity> FindAsync(object[] keyValues, CancellationToken cancellationToken)
        {
            return Task.FromResult(Find(keyValues));
        }

        public new TEntity Remove(TEntity entity)
        {
            if (entity == null)
                throw new ArgumentNullException("entity");
            if (keys.Any(k => k.GetValue(entity) == null))
                throw new ArgumentOutOfRangeException("entity");

            var item = items.SingleOrDefault(i =>
                keys.All(k => k.GetValue(entity).Equals(k.GetValue(i)))
            );

            if (item != null)
                items.Remove(item);
            return item;
        }

        public override void RemoveRange(IEnumerable<TEntity> entities)
        {
            if (entities == null)
                throw new ArgumentNullException("entities");

            entities.Select(Remove).ToList();
        }

        public Type ElementType
        {
            get { return query.ElementType; }
        }

        public Expression Expression
        {
            get { return query.Expression; }
        }

        public IQueryProvider Provider
        {
            get { return query.Provider; }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return query.GetEnumerator();
        }

        public IEnumerator<TEntity> GetEnumerator()
        {
            return query.GetEnumerator();
        }

        IAsyncEnumerator<TEntity> IAsyncEnumerable<TEntity>.GetEnumerator()
        {
            return ((IAsyncEnumerable<TEntity>)query).GetEnumerator();
        }

    }
}
