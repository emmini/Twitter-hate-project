﻿using System;
using System.Collections.Generic;
using System.Linq;
using NewsEventDetection.Extractor.NGram;

namespace NewsEventDetection.Domain
{
    public class Tweet : BaseEntity
    {
        public Tweet()
        {
            TweetJacards = new Dictionary<string, double>();
            SpottingMeasures = new Dictionary<string, double>();
            Topics = new List<string>();
            NGrams = new Dictionary<string, int>();
        }

        private INgramsExtractor extractor;
        public string Text { get; set; }

        public IEnumerable<string> Topics { get; set; }

        public DateTimeOffset Date { get; set; }

        public string FilteredText { get; set; }

        public double DegreeOfSupport { get; set; }

        public IDictionary<string, double> TweetJacards { get; set; }

        public double TweetJaccard => TweetJacards.Values.Max();

        private IDictionary<string, int> ngrams;
        public IDictionary<string, int> NGrams
        {
            get
            {
                if (ngrams == null || !ngrams.Any())
                {
                    if (extractor == null)
                    {
                        extractor = new CharNgramsExtractor();
                    }

                    extractor.Source = string.IsNullOrWhiteSpace(FilteredText) ? Text : FilteredText;
                    extractor.Extract(3);
                    ngrams = extractor.Ngrams;
                }

                return ngrams;
            }
            set => ngrams = value;
        }

        public IDictionary<string, double> SpottingMeasures { get; set; }
    }
}