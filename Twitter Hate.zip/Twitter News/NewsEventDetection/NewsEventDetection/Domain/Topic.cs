﻿using System.Collections.Generic;
using System.Linq;
using NewsEventDetection.Extractor.NGram;

namespace NewsEventDetection.Domain
{
    public class Topic: BaseEntity
    {
        public Topic()
        {
            NGrams = new Dictionary<string, int>();
        }
        private INgramsExtractor extractor;

        public string Value { get; set; }

        private IDictionary<string, int> ngrams;
        public IDictionary<string, int> NGrams
        {
            get
            {
                if (ngrams == null || !ngrams.Any())
                {
                    if (extractor == null)
                    {
                        extractor = new CharNgramsExtractor();
                    }

                    extractor.Source = Value;
                    extractor.Extract(3);
                    ngrams = extractor.Ngrams;
                }

                return ngrams;
            }
            set => ngrams = value;
        }
    }
}
