﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NewsEventDetection.Domain
{
    public partial class Context<T> where T: BaseEntity, new()
    {
        public Context()
        {
            TweetData = new DbSetHelper<T>();
            NewsData = new DbSetHelper<T>();
            Topics = new DbSetHelper<Topic>();
        }

        public Context(string path)
        {
            Path = path;
            LoadTweetData();
            NewsData = new DbSetHelper<T>();
            Topics = new DbSetHelper<Topic>();
        }

        public DbSetHelper<T> TweetData { get; set; }

        public DbSetHelper<T> NewsData { get; set; }

        public DbSetHelper<Topic> Topics { get; set; }

        public string Path { get; set; }

        public Task<T> FindAsync(string id)
        {
            return TweetData.FindAsync(id);
        }

        public DbSetHelper<T> LoadTweetData()
        {
            string data = File.ReadAllText(Path);
            var a = JsonConvert.DeserializeObject<IEnumerable<T>>(data);
            TweetData = new DbSetHelper<T>(a);
            return TweetData;
        }

        public async Task<DbSetHelper<T>> LoadNews(string path)
        {
            string data = await File.ReadAllTextAsync(path);
            var a = JsonConvert.DeserializeObject<IEnumerable<T>>(data);
            NewsData = new DbSetHelper<T>(a);
            return NewsData;
        }

        public async Task<DbSetHelper<Topic>> LoadTopics(string path)
        {
            string data = await File.ReadAllTextAsync(path);
            var a = JsonConvert.DeserializeObject<IEnumerable<Topic>>(data);
            Topics = new DbSetHelper<Topic>(a);
            return Topics;
        }

        public async Task<int> SaveChangesAsync()
        {
            string data = JsonConvert.SerializeObject(TweetData);
            await File.WriteAllTextAsync(Path, data);
            return TweetData.Count();
        }

        public async Task<int> SaveTopicsChangesAsync(string path)
        {
            string data = JsonConvert.SerializeObject(Topics);
             await File.WriteAllTextAsync(path, data);
            return Topics.Count();
        }

    }
}
