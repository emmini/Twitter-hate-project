## Twitter Hate Detector

The NgramsExtractor class generates ngrams from the documents (tweets). The terms used to generate the ngrams are assigned from an abstract method implemented in WordNgramsExtractor and CharNgramsExtractor after the removal of stopwords. The WordNgramsExtractor sets the terms to the words in the tweet. The CharNgramsExtractor sets the terms to the characters.

The TweetRepository is where most of the work happens. The GetTopics method extracts the topics (hashtags) from the tweet based on a syntactic rule that defines Twitter hashtags (the regex: #\w+\b).

The Jaccard similarity between a tweet and a collection of tweets is returned from the GetTweetJaccard method. It computes the max of the Jaccard similarity between two tweets and returns that as the Jaccard.

The GetTopicSpottingMeasure method uses the bayesian principle to compute the topic spotting measure between a tweet and a topic based on a tweet collection.

The ComputeGroupScoresAsync method takes a tweet and computes the score for each group (based on extracted ngrams) in the tweet.